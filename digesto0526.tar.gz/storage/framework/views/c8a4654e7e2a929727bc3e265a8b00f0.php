<div
    <?php echo e($attributes->gridColumn($this->getColumnSpan(), $this->getColumnStart())->class(['fi-wi-widget'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /datos/datos/sites/laravel/digesto0526/vendor/filament/widgets/resources/views/components/widget.blade.php ENDPATH**/ ?>