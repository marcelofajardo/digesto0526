<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /datos/datos/sites/laravel/digesto0526/vendor/filament/support/resources/views/components/dropdown/list/index.blade.php ENDPATH**/ ?>