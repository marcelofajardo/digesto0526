<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo e(config('app.name')); ?> - Documentos</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo filament()->getTheme()->getHtml(); ?>

    <?php echo filament()->getFontPreloadHtml(); ?>

    <?php echo filament()->getMonoFontPreloadHtml(); ?>

    <?php echo filament()->getSerifFontPreloadHtml(); ?>

    <?php echo filament()->getFontHtml(); ?>

    <?php echo filament()->getMonoFontHtml(); ?>

    <?php echo filament()->getSerifFontHtml(); ?>

    <link rel="icon" type="image/png" href="<?php echo e(asset('images/Logo-a-color-chico.png')); ?>">
    <style>
        body { font-family: Inter, ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial; }
    </style>
    
</head>
<body class="antialiased bg-gray-50">
    <!-- Encabezado -->
    <header class="shadow-sm border-b border-gray-200" style="background-color: #E0D9CC;">
        <div class="max-w-7xl mx-auto px-4 py-4">
            <div class="flex items-center justify-between gap-4">
                <!-- Logo a la izquierda -->
                <div class="flex-shrink-0">
                    <img src="<?php echo e(asset('storage/logo.webp')); ?>" alt="Logo" class="h-10 w-auto object-contain">
                </div>

                <!-- Título en el centro -->
                <div class="flex-1 text-center">
                    <h1 class="text-6xl font-black" style="font-family: 'Arial Black', serif; color: #333;">Digesto Institucional - Universidad Nacional de Villa Mercedes</h1>
                </div>

                <!-- Botón de ayuda a la derecha -->
                <div class="flex-shrink-0">
                    <a href="<?php echo e(asset('storage/manual.pdf')); ?>" target="_blank" rel="noopener noreferrer" 
                       class="inline-flex items-center justify-center px-4 py-2 text-white font-semibold rounded-lg transition-colors duration-200 shadow-sm hover:shadow-md" 
                       style="background-color: #b5a788;" 
                       onmouseover="this.style.backgroundColor='#9d9074'" 
                       onmouseout="this.style.backgroundColor='#b5a788'"
                       title="Descargar manual de ayuda">
                        Ayuda
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Contenido principal -->
    <main class="w-full max-w-none px-4 py-4">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split(App\Filament\Widgets\PublicDocumentos::class);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-2421198603-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
    </main>

    <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts(withCore: true) ?>
</body>
</html>
<?php /**PATH /datos/datos/sites/laravel/digesto0526/resources/views/public/documents.blade.php ENDPATH**/ ?>