# Deployment

- Laravel can be deployed using [Laravel Cloud](https://cloud.laravel.com/), which is the fastest way to deploy and scale production Laravel applications.
<?php /**PATH /datos/datos/sites/laravel/digesto0526/storage/framework/views/2d21c7721a51fb6d42304f35ce55c99a.blade.php ENDPATH**/ ?>